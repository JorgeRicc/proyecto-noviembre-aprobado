// pch.cpp: Quelldatei, die dem vorkompilierten Header entspricht

#include "pch.h"

// Bei der Verwendung vorkompilierter Header ist diese Quelldatei für eine erfolgreiche Kompilierung erforderlich.
